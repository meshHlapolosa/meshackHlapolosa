import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-api-details',
  templateUrl: './api-details.component.html',
  styleUrls: ['./api-details.component.css']
})
export class ApiDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
