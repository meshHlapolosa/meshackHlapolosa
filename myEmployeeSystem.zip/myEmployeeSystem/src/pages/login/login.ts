import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {HomePage} from '../home/home';


/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

 // this.navCtrl.push(LoginPage)

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  myUserPassword : string = "12345";
  myUserName : string = "Meshack";



 loginMethod = function(myUserName,myUserPassword){

  console.log(myUserName);

  console.log(myUserPassword);
      if(this.myUserName == myUserName && this.myUserPassword ==myUserPassword){

        this.navCtrl.push(HomePage);
        console.log("Jumping to login page");
      }
    else{
      
      console.log("Stay here..");
      alert("Please ensure that you input the correct details !")
      
    }
 }
}
