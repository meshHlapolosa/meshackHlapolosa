import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {LoginPage}from '../login/login';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  empIdNumber:string;
  empName: string;
  empSurname:string;
  empRole:string;

  // this initiates my employees array
  myEmployeesArray = [
  ];

  // the model allows the table to display what inputed on the form
  model:any={};
  model2:any={};

  // this creates a method that will allow users to add new employees.
 /* addNewEmployee(empIdNumber, empSurname,empName,empRole){
    empIdNumber =this.myEmployeesArray.push(empIdNumber);
    empSurname = this.myEmployeesArray.push(empSurname);
    empName = this.myEmployeesArray.push(empName);
    empRole = this.myEmployeesArray.push(empRole);
    console.log(this.myEmployeesArray);

  }*/

  addNewEmployee = function(empIdNumber, empSurname,empName,empRole){
    let myEmployees = new myEmployeesDetails(empIdNumber, empSurname,empName,empRole);
      this.myEmployeesArray.push(myEmployees);
      console.log(this.myEmployeesArray);
      this.empIdNumber = "";
      this.empSurname = " ";
      this.empName = " ";
      this.empRole = " ";
  }

  // this creates a method that will allow users to delete employees.
  deleteEmployee(i){
    this.myEmployeesArray.splice(i,1);
    
  }

  // this creates a method that will allow users to edit employees.
  myvalue;
  editEmployee(k){
    this.empIdNumber = this.myEmployeesArray[k].name;
    this.empSurname = this.myEmployeesArray[k].empRole;
    this.empName = this.myEmployeesArray[k].name;
    this.empRole = this.myEmployeesArray[k].empRole;
    this.myvalue = k;
  }

  // this creates a method that will allow users to update employees.
  updateEmployee(){
    let k = this.myvalue;
    for(let i=0; i<this.myEmployeesArray.length; i++){
      if(i==k){
          this.myEmployeesArray[i] = this.model2;
          
          
      }
    }
  }
  constructor(public navCtrl: NavController) {

  }

}
export class myEmployeesDetails{
  empIdNumber : string;
  empName : string;
  empSurname : string;
  empRole : string;

  constructor(empIdNumber : string, empName : string, empSurname : string, empRole : string){
          this.empIdNumber = empIdNumber;
          this.empName = empName;
          this.empSurname = empSurname;
          this.empRole = empRole;
  }

}