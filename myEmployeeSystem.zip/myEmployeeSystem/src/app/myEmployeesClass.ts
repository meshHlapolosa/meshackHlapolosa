export class myEmployeesDetails{
    empIdNumber : string;
    empName : string;
    empSurname : string;
    empRole : string;

    constructor(empIdNumber : string, empName : string, empSurname : string, empRole : string){
            this.empIdNumber = empIdNumber;
            this.empName = empName;
            this.empSurname = empSurname;
            this.empRole = empRole;
    }

}