import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {HomePage} from '../../pages/home/home';
import PouchDB from 'pouchdb-browser';
import cordovaSqlitePlugin from 'pouchdb-adapter-cordova-sqlite';

/**
 * Generated class for the NewPersonPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-new-person',
  templateUrl: 'new-person.html',
})
export class NewPersonPage {
  private name ;
  private email ;
  private phone ;

  private db;
  private person; // this will hbe edited

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  setupDB(){
    this.db = new PouchDB ('contacts');
  }

  ionViewDidLoad() {
    this.setupDB();
    if(this.navParams.get('person_id') != null){
        this.db.get(this.navParams.get('person_id'), (err , result) => {
          if(!err){
            console.log(result);
            this.person = result ;
            this.name = result.name ;
            this.email = result.email ;
            this.phone = result.phone ; 
          }
        })
    }
    
    console.log('ionViewDidLoad NewPersonPage');
  }

  save(){

    if(this.person){
      // this updates a selected person
      this.person.name = this.name ;
      this.person.email = this.email ;
      this.person.phone = this.phone ;
        this.db.put(this.person , (err, result) => {
          if(!err){
            alert('Person upadted succesfully');
            this.navCtrl.pop();
          }
        })
    } else {
      // this creates a new person
    this.db.post({
      name : this.name,
      email : this.email,
      phone : this.phone  
    }, (err , result ) =>{
      if(!err){
        alert('One person added');
        this.navCtrl.pop();
      } 
    
    });
  } 
  }

  cancel(){
    this.navCtrl.pop();
  }

}
