import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {NewPersonPage} from '../../pages/new-person/new-person';
import PouchDB from 'pouchdb-browser';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  private persons ;
  private db;

  constructor(public navCtrl: NavController) {

  }

  ionViewDidEnter(){
   this.refresh();
  }

  refresh(){
    this.db = new PouchDB ('contacts');
      this.persons = [];
      this.db.allDocs({include_docs: true}, (err, result)=>{
        if(!err){
            let rows = result.rows;
            for(let i = 0 ; i < rows.length ;i++){
              this.persons.push(rows[i].doc);
            }
        }
      })
  }

  createNew(){

    this.navCtrl.push(NewPersonPage);
  }

  edit(person){
    this.navCtrl.push(NewPersonPage , {
      person_id: person._id
    })

  }

  delete(person){

    if(confirm('are you sure you want to delete?')){
     this.db.remove(person, (err , result) => {
        if(!err){
          alert('Person deleted ! ');
          this.refresh();
        }
    }) 
    }
    

    }
  

}
