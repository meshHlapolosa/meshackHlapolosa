import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-native-api',
  templateUrl: './native-api.component.html',
  styleUrls: ['./native-api.component.css']
})
export class NativeAPIComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
