import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theming-page',
  templateUrl: './theming-page.component.html',
  styleUrls: ['./theming-page.component.css']
})
export class ThemingPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
